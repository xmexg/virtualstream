package org.looom.virtualstream.pages

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun LocalStreamPage(modifier: Modifier = Modifier) {
    Text("这里是本地串流页面", modifier = modifier)
}