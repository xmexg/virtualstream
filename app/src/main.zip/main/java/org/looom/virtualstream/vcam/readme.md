# org.looom.virtualstream.vcam
感谢 https://github.com/Xposed-Modules-Repo/com.example.vcam 的代码,  
这目录完全是从 https://github.com/Xposed-Modules-Repo/com.example.vcam/tree/main/app/src/main/java/com/example/vcam 摘抄过来的  
还修改了文件读写路径从 `/storage/emulated/0/DCIM/Camera1/` 改到了 `/storage/emulated/0/DCIM/virtualstream/`  

